module.exports = {
    transpileDependencies: [
        'vuetify'
    ]
}
