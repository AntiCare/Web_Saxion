<template>
    <div class="container">
        boo
        <div id="page">
<!--            <transition name="fade">-->
                <router-view>boo</router-view>
<!--            </transition>-->
        </div>
    </div>
</template>

<style>

</style>

<script>

    // export default{
    //     data(){
    //         return{

    //         }
    //     }
    // }
</script>
